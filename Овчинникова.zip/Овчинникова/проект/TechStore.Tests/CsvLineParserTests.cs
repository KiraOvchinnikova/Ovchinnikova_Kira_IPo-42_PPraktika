﻿using TechStore.Web.Services;
using Xunit;

namespace TechStore.Tests
{
    public class CsvLineParserTests
    {
        [Fact]
        public void Parse_SimpleLine_ReturnsCorrectFields()
        {
            var line = "1001,Ноутбук,45990,RUB";
            var result = CsvLineParser.Parse(line);
            Assert.Equal(4, result.Count);
            Assert.Equal("1001", result[0]);
        }

        [Fact]
        public void Parse_EmptyFields_ReturnsEmptyStrings()
        {
            var line = "1011,Блок питания,,4990";
            var result = CsvLineParser.Parse(line);
            Assert.Equal(4, result.Count);
            Assert.Equal(string.Empty, result[2]);
        }

        [Fact]
        public void Parse_CommaInsideQuotes_DoesNotSplitField()
        {
            var line = "1012,\"Ноутбук, игровой\",59990";
            var result = CsvLineParser.Parse(line);
            Assert.Equal(3, result.Count);
            Assert.Equal("Ноутбук, игровой", result[1]);
        }

        [Fact]
        public void Parse_EscapedQuotes_ReturnsCorrectString()
        {
            var line = "1013,\"Название \"\"Special\"\"\",100";
            var result = CsvLineParser.Parse(line);
            Assert.Equal("Название \"Special\"", result[1]);
        }
    }
}