﻿using TechStore.Web.Models;
using TechStore.Web.Services;
using Xunit;

namespace TechStore.Tests
{
    public class RepositoryTests
    {
        [Fact]
        public void Add_AddsProduct_GetAllContainsIt()
        {
            var repository = new InMemoryProductRepository();
            var product = new Product { Sku = "1001", Name = "Ноутбук Lenovo", Price = 45990m };
            repository.Add(product);
            var all = repository.GetAll();
            Assert.Single(all);
            Assert.Equal("1001", all[0].Sku);
        }

        [Fact]
        public void GetBySku_ReturnsProduct()
        {
            var repository = new InMemoryProductRepository();
            repository.Add(new Product { Sku = "1001", Name = "Ноутбук" });
            var found = repository.GetBySku("1001");
            Assert.NotNull(found);
            Assert.Equal("1001", found.Sku);
        }

        [Fact]
        public void GetBySku_IgnoresCaseAndSpaces()
        {
            var repository = new InMemoryProductRepository();
            repository.Add(new Product { Sku = "1001", Name = "Ноутбук" });
            var found = repository.GetBySku(" 1001 ");
            Assert.NotNull(found);
        }

        [Fact]
        public void EmptyRepository_ReturnsZeroAndNull()
        {
            var repository = new InMemoryProductRepository();
            Assert.Equal(0, repository.Count);
            Assert.Empty(repository.GetAll());
            Assert.Null(repository.GetBySku("1001"));
        }
    }
}