﻿using TechStore.Web.Models;
using TechStore.Web.Services;
using System.IO;
using System.Linq;
using Xunit;

namespace TechStore.Tests
{
    public class ProductImportServiceTests
    {
        private const string Header = "sku,name,description,price,currency,category_name,stock,image_url,is_active,brand,warranty_months,model_number";
        private const string ValidRow = "1001,Ноутбук Lenovo,Бюджетный,45990,RUB,Компьютеры,5,/img.jpg,true,Lenovo,24,IdeaPad";

        [Fact]
        public void ImportFromLines_ValidRow_ImportsSuccessfully()
        {
            var repo = new InMemoryProductRepository();
            var service = new ProductImportService(repo);
            var result = service.ImportFromLines(new[] { Header, ValidRow });

            Assert.Equal(1, result.TotalRows);
            Assert.Equal(1, result.ImportedCount);
            Assert.Empty(result.Errors);
            Assert.NotNull(repo.GetBySku("1001"));
        }

        [Fact]
        public void ImportFromLines_MultipleRows_ImportsAll()
        {
            var repo = new InMemoryProductRepository();
            var service = new ProductImportService(repo);
            var row2 = "1002,Мышь,Беспроводная,1290,RUB,Периферия,10,/img.jpg,true,Logitech,12,M185";
            var result = service.ImportFromLines(new[] { Header, ValidRow, row2 });

            Assert.Equal(2, result.TotalRows);
            Assert.Equal(2, result.ImportedCount);
            Assert.Equal(2, repo.Count);
        }

        [Fact]
        public void ImportFromCsv_FileNotFound_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var result = service.ImportFromCsv("C:\\nonexistent_file.csv");
            Assert.Contains("Файл не найден", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromCsv_EmptyFile_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var path = Path.GetTempFileName();
            File.WriteAllText(path, string.Empty);
            try
            {
                var result = service.ImportFromCsv(path);
                Assert.Contains("Данные для импорта отсутствуют", result.Errors[0].Message);
            }
            finally { File.Delete(path); }
        }

        [Fact]
        public void ImportFromLines_OnlyHeader_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var result = service.ImportFromLines(new[] { Header });
            Assert.Contains("Данные для импорта отсутствуют", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_WrongHeader_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var result = service.ImportFromLines(new[] { "sku,name,price", ValidRow });
            Assert.Contains("Неверные заголовки CSV", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_WrongColumnsCount_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var result = service.ImportFromLines(new[] { Header, "1001,Только_два_поля" });
            Assert.Contains("Неверное количество полей в строке", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_EmptySku_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = ",Ноутбук,Описание,45990,RUB,Компьютеры,5,/img.jpg,true,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле sku не может быть пустым", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_EmptyName_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,,Описание,45990,RUB,Компьютеры,5,/img.jpg,true,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле name не может быть пустым", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_NegativePrice_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,-500,RUB,Компьютеры,5,/img.jpg,true,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле price должно быть числом больше 0", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_NonNumericPrice_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,abc,RUB,Компьютеры,5,/img.jpg,true,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле price должно быть числом больше 0", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_NegativeStock_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,45990,RUB,Компьютеры,-5,/img.jpg,true,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Остаток на складе должен быть целым числом не меньше 0", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_BadIsActive_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,45990,RUB,Компьютеры,5,/img.jpg,yes,Lenovo,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле is_active должно иметь значение true, false, 1 или 0", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_MissingBrand_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,45990,RUB,Компьютеры,5,/img.jpg,true,,24,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Поле brand обязательно для варианта «Электроника»", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_WarrantyLessThanZero_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,45990,RUB,Компьютеры,5,/img.jpg,true,Lenovo,-1,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Гарантия должна быть целым числом от 0 до 60 месяцев", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_WarrantyGreaterThan60_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1001,Ноутбук,Описание,45990,RUB,Компьютеры,5,/img.jpg,true,Lenovo,61,IdeaPad";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Contains("Гарантия должна быть целым числом от 0 до 60 месяцев", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_DuplicateSkuInFile_ReturnsError()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var result = service.ImportFromLines(new[] { Header, ValidRow, ValidRow });
            Assert.Equal(2, result.TotalRows);
            Assert.Equal(1, result.ImportedCount);
            Assert.Contains("Артикул товара уже существует", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_DuplicateSkuInRepository_ReturnsError()
        {
            var repo = new InMemoryProductRepository();
            repo.Add(new Product { Sku = "1001" });
            var service = new ProductImportService(repo);
            var result = service.ImportFromLines(new[] { Header, ValidRow });
            Assert.Contains("Артикул товара уже существует", result.Errors[0].Message);
        }

        [Fact]
        public void ImportFromLines_MultipleErrorsInRow_ReturnsMultipleErrors()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = ",,Некорректная,-10,RUB,Компьютеры,-5,/x.jpg,yes,,61,SomeModel";

            var result = service.ImportFromLines(new[] { Header, row });

            Assert.True(result.Errors.Count >= 4);
            Assert.Equal(0, result.ImportedCount);
        }

        [Fact]
        public void ImportFromLines_EmptyOptionalFields_ImportsSuccessfully()
        {
            var service = new ProductImportService(new InMemoryProductRepository());
            var row = "1011,Блок питания,,4990,RUB,Компьютеры,9,,true,Corsair,60,CV550";
            var result = service.ImportFromLines(new[] { Header, row });
            Assert.Equal(1, result.ImportedCount);
            Assert.Empty(result.Errors);
        }

        [Fact]
        public void ImportFromLines_EmptyCurrency_DefaultsToRub()
        {
            var repo = new InMemoryProductRepository();
            var service = new ProductImportService(repo);
            var row = "1011,Блок питания,Описание,4990,,Компьютеры,9,/img.jpg,true,Corsair,60,CV550";
            service.ImportFromLines(new[] { Header, row });
            Assert.Equal("RUB", repo.GetBySku("1011").Currency);
        }

        [Fact]
        public void ImportFromLines_EmptyCategory_DefaultsToNoCategory()
        {
            var repo = new InMemoryProductRepository();
            var service = new ProductImportService(repo);
            var row = "1011,Блок питания,Описание,4990,RUB,,9,/img.jpg,true,Corsair,60,CV550";
            service.ImportFromLines(new[] { Header, row });
            Assert.Equal("Без категории", repo.GetBySku("1011").CategoryName);
        }

        [Fact]
        public void ImportFromLines_Cyrillic_ImportsCorrectly()
        {
            var repo = new InMemoryProductRepository();
            var service = new ProductImportService(repo);
            service.ImportFromLines(new[] { Header, ValidRow });
            Assert.Equal("Ноутбук Lenovo", repo.GetBySku("1001").Name);
        }
    }
}