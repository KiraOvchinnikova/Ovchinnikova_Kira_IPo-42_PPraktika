﻿namespace TechStore.Web.Models
{
    public class ProductsIndexViewModel
    {
        public IReadOnlyList<Product> Products { get; set; } = new List<Product>();
        public int TotalCount => Products.Count;
        public decimal TotalValue => Products.Sum(p => p.Price);

        public string SearchQuery { get; set; } = string.Empty;
        public string CategoryFilter { get; set; } = string.Empty;
        public string SortOrder { get; set; } = string.Empty;
        public List<string> AvailableCategories { get; set; } = new List<string>();
    }
}