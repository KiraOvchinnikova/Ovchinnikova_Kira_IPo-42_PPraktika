﻿using Microsoft.AspNetCore.Mvc;
using TechStore.Web.Models;
using TechStore.Web.Services;
using System.Text;

namespace TechStore.Web.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProductRepository _repository;
        private readonly IProductImportService _importService;
        private readonly IWebHostEnvironment _environment;

        public ProductsController(
            IProductRepository repository,
            IProductImportService importService,
            IWebHostEnvironment environment)
        {
            _repository = repository;
            _importService = importService;
            _environment = environment;
        }

        public IActionResult Index(string searchString, string category, string sortOrder)
        {
            var products = _repository.GetAll().AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchString))
                products = products.Where(p => p.Name.Contains(searchString, StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(category))
                products = products.Where(p => p.CategoryName == category);

            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";
            ViewData["StockSortParm"] = sortOrder == "Stock" ? "stock_desc" : "Stock";
            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentCategory"] = category;

            switch (sortOrder)
            {
                case "sku_desc": products = products.OrderByDescending(p => p.Sku); break;
                case "Sku": products = products.OrderBy(p => p.Sku); break;
                case "name_desc": products = products.OrderByDescending(p => p.Name); break;
                case "Price": products = products.OrderBy(p => p.Price); break;
                case "price_desc": products = products.OrderByDescending(p => p.Price); break;
                case "Stock": products = products.OrderBy(p => p.StockQuantity); break;
                case "stock_desc": products = products.OrderByDescending(p => p.StockQuantity); break;
                default: products = products.OrderBy(p => p.Sku); break; 
            }

            var viewModel = new ProductsIndexViewModel
            {
                Products = products.ToList(),
                SearchQuery = searchString ?? "",
                CategoryFilter = category ?? "",
                SortOrder = sortOrder ?? "",
                AvailableCategories = _repository.GetAll().Select(p => p.CategoryName).Distinct().ToList()
            };

            return View(viewModel);
        }

        public IActionResult Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();
            var product = _repository.GetBySku(id);
            if (product == null) return NotFound();
            return View(product);
        }

        public IActionResult ExportCsv()
        {
            var products = _repository.GetAll();
            var builder = new StringBuilder();
            builder.AppendLine("sku,name,description,price,currency,category_name,stock,image_url,is_active,brand,warranty_months,model_number");

            foreach (var p in products)
            {
                builder.AppendLine($"{p.Sku},{p.Name},\"{p.Description}\",{p.Price},{p.Currency},{p.CategoryName},{p.StockQuantity},{p.ImageUrl},{p.IsActive.ToString().ToLower()},{p.Brand},{p.WarrantyMonths},{p.ModelNumber}");
            }

            var bytes = Encoding.UTF8.GetBytes(builder.ToString());
            return File(bytes, "text/csv", "products_export.csv");
        }

        [HttpGet]
        public IActionResult Import()
        {
            return View(new ImportViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Import(string filePath, IFormFile file)
        {
            ImportResult? result = null;

            if (file != null && file.Length > 0)
            {
                using var reader = new StreamReader(file.OpenReadStream());
                var lines = new List<string>();
                while (!reader.EndOfStream)
                {
                    lines.Add(reader.ReadLine() ?? "");
                }
                result = _importService.ImportFromLines(lines);
            }
            else if (!string.IsNullOrWhiteSpace(filePath))
            {
                string resolvedPath = filePath;
                if (filePath.StartsWith("/"))
                {
                    resolvedPath = Path.Combine(_environment.WebRootPath, filePath.TrimStart('/'));
                }
                result = _importService.ImportFromCsv(resolvedPath);
            }
            else
            {
                ModelState.AddModelError("", "Укажите путь к файлу или загрузите файл.");
                return View(new ImportViewModel { FilePath = filePath });
            }

            return View(new ImportViewModel { FilePath = filePath, Result = result });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Clear()
        {
            _repository.Clear();
            return RedirectToAction(nameof(Index));
        }
    }
}