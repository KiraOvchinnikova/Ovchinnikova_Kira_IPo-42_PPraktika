﻿using TechStore.Web.Models;

namespace TechStore.Web.Services
{
    public class ProductImportService : IProductImportService
    {
        private readonly IProductRepository _repository;

        public ProductImportService(IProductRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public ImportResult ImportFromCsv(string filePath)
        {
            var result = new ImportResult();

            if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            {
                result.Errors.Add(new ImportError { RowNumber = 0, Message = "Файл не найден" });
                LogError("Файл не найден: " + filePath);
                return result;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                return ImportFromLines(lines);
            }
            catch (Exception ex)
            {
                result.Errors.Add(new ImportError { RowNumber = 0, Message = $"Ошибка чтения файла: {ex.Message}" });
                LogError($"Ошибка чтения файла {filePath}: {ex.Message}");
                return result;
            }
        }

        public ImportResult ImportFromLines(IEnumerable<string> lines)
        {
            var result = new ImportResult();
            var allLines = lines.ToList();

            if (allLines.Count == 0 || allLines.All(string.IsNullOrWhiteSpace))
            {
                result.Errors.Add(new ImportError { RowNumber = 0, Message = "Данные для импорта отсутствуют" });
                LogError("Данные для импорта отсутствуют (пустой файл)");
                return result;
            }

            int headerIndex = allLines.FindIndex(l => !string.IsNullOrWhiteSpace(l));
            var headerCols = CsvLineParser.Parse(allLines[headerIndex]);

            var colMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < headerCols.Count; i++)
            {
                var colName = headerCols[i].Trim();
                if (!colMap.ContainsKey(colName))
                    colMap[colName] = i;
            }

            string[] requiredCols = { "sku", "name", "description", "price", "currency", "category_name", "stock", "image_url", "is_active", "brand", "warranty_months", "model_number" };
            if (requiredCols.Any(c => !colMap.ContainsKey(c)))
            {
                result.Errors.Add(new ImportError { RowNumber = headerIndex + 1, Message = "Неверные заголовки CSV" });
                LogError($"Неверные заголовки CSV (строка {headerIndex + 1})");
                return result;
            }

            var importedSkus = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = headerIndex + 1; i < allLines.Count; i++)
            {
                var line = allLines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;

                result.TotalRows++;
                int rowNum = i + 1;

                var values = CsvLineParser.Parse(line);

                if (values.Count != headerCols.Count)
                {
                    result.Errors.Add(new ImportError { RowNumber = rowNum, Message = "Неверное количество полей в строке" });
                    LogError($"Строка {rowNum}: Неверное количество полей в строке");
                    continue;
                }

                var rowErrors = new List<ImportError>();
                string GetValue(string col) => colMap.TryGetValue(col, out int idx) && idx < values.Count ? values[idx] : string.Empty;

                string sku = GetValue("sku");
                if (string.IsNullOrWhiteSpace(sku)) rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Поле sku не может быть пустым" });

                string name = GetValue("name");
                if (string.IsNullOrWhiteSpace(name)) rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Поле name не может быть пустым" });

                decimal price = 0;
                if (!decimal.TryParse(GetValue("price"), out price) || price <= 0)
                    rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Поле price должно быть числом больше 0" });

                int stock = 0;
                if (!int.TryParse(GetValue("stock"), out stock) || stock < 0)
                    rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Остаток на складе должен быть целым числом не меньше 0" });

                string isActiveStr = GetValue("is_active").ToLowerInvariant();
                bool isActive = isActiveStr == "true" || isActiveStr == "1";
                if (!(isActiveStr == "true" || isActiveStr == "false" || isActiveStr == "1" || isActiveStr == "0"))
                    rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Поле is_active должно иметь значение true, false, 1 или 0" });

                string brand = GetValue("brand");
                if (string.IsNullOrWhiteSpace(brand)) rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Поле brand обязательно для варианта «Электроника»" });

                int warranty = 0;
                if (!int.TryParse(GetValue("warranty_months"), out warranty) || warranty < 0 || warranty > 60)
                    rowErrors.Add(new ImportError { RowNumber = rowNum, Message = "Гарантия должна быть целым числом от 0 до 60 месяцев" });

                if (rowErrors.Count > 0)
                {
                    result.Errors.AddRange(rowErrors);
                    foreach (var err in rowErrors) LogError($"Строка {err.RowNumber}: {err.Message}");
                    continue;
                }

                bool isDuplicate = _repository.GetBySku(sku) != null || importedSkus.Contains(sku);
                if (isDuplicate)
                {
                    result.Errors.Add(new ImportError { RowNumber = rowNum, Message = "Артикул товара уже существует" });
                    LogError($"Строка {rowNum}: Артикул товара {sku} уже существует");
                    continue;
                }

                string currency = GetValue("currency");
                if (string.IsNullOrWhiteSpace(currency)) currency = "RUB";
                else currency = currency.ToUpperInvariant();

                string category = GetValue("category_name");
                if (string.IsNullOrWhiteSpace(category)) category = "Без категории";

                var product = new Product
                {
                    Sku = sku.Trim(),
                    Name = name.Trim(),
                    Description = GetValue("description").Trim(),
                    Price = price,
                    Currency = currency,
                    CategoryName = category,
                    StockQuantity = stock,
                    ImageUrl = GetValue("image_url").Trim(),
                    IsActive = isActive,
                    Brand = brand.Trim(),
                    WarrantyMonths = warranty,
                    ModelNumber = GetValue("model_number").Trim()
                };

                _repository.Add(product);
                importedSkus.Add(sku);
                result.ImportedCount++;
            }

            if (result.TotalRows == 0 && result.Errors.Count == 0)
            {
                result.Errors.Add(new ImportError { RowNumber = 0, Message = "Данные для импорта отсутствуют" });
                LogError("Данные для импорта отсутствуют (нет строк данных)");
            }

            return result;
        }

        private void LogError(string message)
        {
            try
            {
                string logPath = Path.Combine(Directory.GetCurrentDirectory(), "import_errors.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}");
            }
            catch { }
        }
    }
}