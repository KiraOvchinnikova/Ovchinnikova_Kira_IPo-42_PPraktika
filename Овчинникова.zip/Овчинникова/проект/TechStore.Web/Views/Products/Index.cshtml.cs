using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TechStore.Web.Views.Products
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
